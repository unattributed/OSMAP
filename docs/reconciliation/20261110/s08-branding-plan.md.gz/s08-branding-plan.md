# S08-05 — Shared OSMAP branding

Date: 2026-11-09 (Asia/Bangkok).

State: **CONTRACT_DEFINED**. Implementation, Rust/native execution, browser verification, installed verification and owner UAT: **NOT_RUN for this extension**.

## Scope and outcome

The owner accepted the original S08 sprint. Preserve that acceptance. These subsequently requested extensions run in order: **S08-05 shared branding**, **S08-06 account-specific icon display mode**, then **S08-07 Junk folder**. S09 has not started under this contract. Documents remains removed from scope.

S08-05 makes the login page's existing shield/keyhole mark and exact **OSMAP / Secure Webmail** wording the shared brand on internal pages, including alternate headers. Reuse the existing asset, Rust rendering and styles. The brand must remain legible and correctly proportioned at desktop and narrow widths, in supported themes and densities.

Preserve authentication, password/TOTP requirements, session and personal-key permissions, mail actions, storage reporting and saved preferences. This slice requires no Toronto changes or mail configuration changes, new service, dependency, framework or Python tooling.

## Baseline and implementation ownership

Planning baseline: detached HEAD `501f6430a5ec2eda95e8d6a942fee2268ab4e6a6`; delivery branch `feat/ux-completion-20260929`. Existing changes in `src/http_ui.rs`, `docs/CURRENT_PROJECT_STATUS.md`, `docs/UX_EXECUTION_LEDGER.md` and `docs/UX_SLICE_S08_03.md` must be preserved and reconciled, not overwritten.

`src/http_ui.rs` already contains partial branding changes referring to `OSMAP_BRAND_SHIELD` and shared brand copy. Their build and completeness have not been verified in this planning work. Treat these as existing work to inspect at T01, not proof of completion or an observed compiler failure.

Root owns integration and the evidence record. Independent review during implementation checks scope, regression coverage and installed claims; no independent review is claimed by this planning document. Future evidence location: `/home/foo/Downloads/osmap-ux-s08/s08-05/`.

## Required S05 failure-analysis loop — all new S08 slices

Apply this execution contract to S08-05, S08-06 and S08-07:

1. Record the specific expected behaviour and observed failure at the actual product boundary.
2. Trace its cause through existing working code and tests; identify what can be reused.
3. Establish the smallest meaningful regression check appropriate to the failure and its risk.
4. Make the smallest correction supported by the evidence. Avoid speculative architecture or unrelated changes.
5. Retest the original failing path and the essential negative cases. Record expected result, observed result, cause, correction, evidence and verdict.
6. Reuse accepted evidence for unchanged behaviour. Repeat a broader suite only when a changed boundary, failure or unresolved concern justifies it.
7. After two failures at the same boundary, obtain an independent reassessment of the cause and approach. Preserve cumulative failure history; do not reset the count or blindly repeat the same attempt.
8. Run the applicable normal candidate gates once, then verify the corresponding installed OpenBSD behaviour before claiming readiness.
9. Distinguish source checks, native checks, browser checks, installed checks and owner acceptance. Give the owner a short functional UAT only after agent-owned engineering verification succeeds.
10. Reuse Rust/native tools and established project tests. Add no Python tooling, new framework, service, dependency or account-specific implementation for these corrections.

The model is the completed S05 work: bounded tasks, actual Rust/helper/browser paths, explicit negative checks, truthful failures, preservation of account authority, and owner acceptance separate from engineering evidence. A failed check returns to analysis and correction; a task number alone is not a PASS.

## T01–T09 tasks and tests

| Task | Required work and verification | Passing evidence |
| --- | --- | --- |
| **T01 — Baseline and contract** | Inventory login, shared shell and alternate brand headers. Reconcile the partial branding change. During implementation, establish the current build result and record expected versus observed differences. | Finite list of affected renderers/routes and reusable asset/helper; existing changes preserved; baseline failures recorded accurately. |
| **T02 — Shared implementation** | Reuse the login shield/keyhole and exact `OSMAP` / `Secure Webmail` copy through existing Rust rendering and styles. Correct header sizing using the established layout. | One consistent brand source, correct home navigation and no obsolete internal tagline in affected headers; no new asset dependency or duplicated redesign. |
| **T03 — Focused Rust regression** | Extend existing renderer tests only where needed to check the shared mark, wording, home link and absence of the obsolete variant. Avoid tests that merely duplicate the SVG implementation. | Focused tests distinguish the reported inconsistency from the corrected output and pass after the correction. |
| **T04 — Route coverage** | Check login, Mailbox, Inbox, Compose, Drafts, Outbox, Sent, Contacts, Folders, Labels, Archive/Bin, Search, Notifications, all Settings sections, personal keys, authentication/recovery, source views and applicable error headers. | Every applicable header uses the same brand exactly once; route-specific content and actions still render. Record routes without a brand header as not applicable. |
| **T05 — Security and accessibility** | Verify the mark uses trusted local content without an external fetch or unsafe SVG behaviour. Check accessible name, keyboard navigation and focus. Preserve escaping, authenticated navigation and existing permission boundaries. | Brand link has a meaningful accessible name and one expected focus target; no external resource dependency, unescaped account content or authentication/key-permission change. |
| **T06 — Real-browser visual checks** | Inspect desktop and narrow layouts, light/dark/system appearance, compact/comfortable density and 200% zoom using existing browser tooling. Use controlled accounts and sanitized evidence. | No clipping, overlap, distortion, unreadable subtitle or displaced controls. Record the browser/layout combinations actually observed. |
| **T07 — Candidate gates** | Run focused Rust checks, formatting, Clippy and the repository's applicable normal/security gates for the final candidate. Reuse unchanged authentication and cryptographic evidence. | Relevant gates pass; failures are analysed and corrected through the loop. No claim that unrelated suites were rerun. |
| **T08 — Installed OpenBSD verification** | Build/check the corresponding native candidate and install only the authorized web correction with readiness and rollback checks. Verify representative live pages with existing services and accounts. | Installed candidate matches the reviewed source; live branding and existing login/navigation work; no Toronto or mail-configuration mutation. |
| **T09 — Owner UAT** | After engineering verification, ask the owner to inspect the login brand, an internal mailbox page, Settings and a narrow layout. | Owner confirms consistent shield/keyhole, `OSMAP` / `Secure Webmail`, readable layout and usable navigation. Record owner verdict separately from agent QA. |

All tasks are pending execution. A discovered failure may require a correction within the same task; do not mark later evidence complete in advance.

## Following extensions — boundaries for their own T01–T09 contracts

**S08-06 — Icon display mode:** add an optional, authenticated-account Appearance preference using existing Rust preference handling. Apply it to action controls on **all pages**, with mouse-over text, keyboard/focus access and an understandable touch interaction. Keep form labels, message content and destructive confirmations readable. Verify default normal mode, persistence, invalid-value fallback, two-account isolation and action parity. Define the complete T01–T09 contract before its implementation.

**S08-07 — Junk folder:** use the authenticated account's native folder inventory and existing Rust mailbox actions. Reuse an existing Spam/Junk folder where appropriate; provide navigation, reading and moves into and out of it, plus ordinary Trash handling. Verify missing-folder behaviour and reject foreign-account or forged-path access. Do not add per-user services or imply spam-filter training that the backend does not perform. Define the complete T01–T09 contract before its implementation.
